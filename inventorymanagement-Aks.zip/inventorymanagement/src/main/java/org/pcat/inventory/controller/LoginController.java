package org.pcat.inventory.controller;

import javax.servlet.http.HttpServletRequest;

import org.pcat.inventory.model.User;
import org.pcat.inventory.service.LoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController
public class LoginController {

	@Autowired
	private LoginService loginService;

	/**
	 * @return the LoginService
	 */
	public LoginService getUserLoginManagementService() {
		return loginService;
	}

	/**
	 * @param loginService
	 *            the LoginService to set
	 */
	public void setUserLoginManagementService(LoginService loginService) {
		this.loginService = loginService;
	}

	/**
	 * Method to validate user from the Database.
	 * 
	 * @param request
	 * @param model
	 * @return String value using which front end can decide on hiding the
	 *         navigation.
	 */
	@RequestMapping(value = "/loginPage", method = RequestMethod.POST)
	public ModelAndView isUserLoggedIn(HttpServletRequest request, Model model) {
		String email = request.getParameter("email");
		User user = loginService.validateUserLogin(email);
		String forward = null;
		if (user != null) {
			if (user.getRole().contains("admin")) {
				forward = "adminPage";
			} else if (user.getRole().contains("supervisor")) {
				forward = "supervisorPage";
			} else {
				forward = "homeVisitorPage";
			}
		}
		return new ModelAndView(forward);
	}

}

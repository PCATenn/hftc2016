package org.pcat.inventory.controller;

import javax.servlet.http.HttpServletRequest;

import org.pcat.inventory.service.RequestApprovalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController
public class RequestApprovalController {
	
	@Autowired
	private RequestApprovalService requestApprovalService;

	/**
	 * @return the RequestApprovalService
	 */
	public RequestApprovalService getRequestApprovalService() {
		return requestApprovalService;
	}

	/**
	 * @param requestApprovalService
	 *            the RequestApprovalService to set
	 */
	public void setRequestApprovalService(RequestApprovalService requestApprovalService) {
		this.requestApprovalService = requestApprovalService;
	}

	/**
	 * This method approves requests and updates the database for approved inventory.
	 * 
	 * @param request
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/requestApproval", method = RequestMethod.POST)
	public ModelAndView approveRequests(HttpServletRequest request, Model model) {
		int userId = Integer.valueOf(request.getParameter("userID"));
		int familyId = Integer.valueOf(request.getParameter("familyId"));
		int inventoryId = Integer.valueOf(request.getParameter("inventoryId"));
		int familyInventoryId = Integer.valueOf(request.getParameter("familyInventoryId"));
		requestApprovalService.approveRequests(userId,familyId,inventoryId,familyInventoryId);
		return new ModelAndView("success");
	}



}

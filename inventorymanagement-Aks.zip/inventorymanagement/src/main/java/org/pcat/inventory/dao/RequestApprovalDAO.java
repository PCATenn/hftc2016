package org.pcat.inventory.dao;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.pcat.inventory.model.FamilyInventory;
import org.pcat.inventory.model.Inventory;
import org.pcat.inventory.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailSender;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.stereotype.Repository;

@Repository
public class RequestApprovalDAO {
	
	@Autowired
	private SessionFactory sessionFactory;
	
	@Autowired
	private MailSender mailSender;

	/**
	 * @return the sessionFactory
	 */
	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	/**
	 * @param sessionFactory
	 *            the sessionFactory to set
	 */
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	/**
	 * @return the mailSender
	 */
	public MailSender getMailSender() {
		return mailSender;
	}

	/**
	 * @param mailSender
	 *            the mailSender to set
	 */
	public void setMailSender(MailSender mailSender) {
		this.mailSender = mailSender;
	}
	
	/**
	 * This method approves the request and updates FamilyInventory and Inventory repositories 
	 * and also sends the notification to homevisitor who requested this order.
	 * @param userId : homevisitor id
	 * @param familyId : familyId
	 * @param inventoryId
	 * @param familyInventoryId
	 * @return
	 */
	public boolean approveRequests(int userId,int familyId,int inventoryId, int familyInventoryId) {
		Transaction tx = null;
		try {
			Session session = sessionFactory.openSession();
			tx = session.beginTransaction();
			Criteria criteria = session.createCriteria(Inventory.class);
			criteria.add(Restrictions.eq("id", inventoryId));
			if( criteria.list().isEmpty() == false)
			{
				Inventory inventory = ((Inventory) criteria.list().get(0));
				criteria = session.createCriteria(FamilyInventory.class);
				criteria.add(Restrictions.eq("id", familyInventoryId));
				int quantity = 0;
				if(criteria.list().isEmpty() == false){
					FamilyInventory familyInventory = (FamilyInventory)criteria.list().get(0);
					quantity = familyInventory.getQuantity();
					
					int total = inventory.getTotalInventory() - quantity;
					inventory.setTotalInventory(total);
					InventoryManagementDAO inventoryManagementDAO = new InventoryManagementDAO();
					if(total !=0 ){
						int reservedInventory = inventory.getReservedInventory() - quantity;
						inventory.setReservedInventory(reservedInventory);
						inventoryManagementDAO.updateInventory(inventory);
					}
					else{
						inventoryManagementDAO.deleteInventory(inventory);
					}								
					familyInventory.setStatus("Approved");
					if(updateFamilyInventory(familyInventory)){
						return sendNotification(userId,familyInventory);
					}
				}
			}
			tx.commit();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	/**
	 * This method sends notification to homevisitor who made the request for the inventory.
	 * @param userId
	 * @param familyInventory
	 * @return
	 */
	private boolean sendNotification(int userId, FamilyInventory familyInventory) 
	{
		boolean completedApproval = false;
		Transaction tx = null;
		try {
			Session session = sessionFactory.openSession();
			tx = session.beginTransaction();
			Criteria criteria = session.createCriteria(User.class);
			criteria.add(Restrictions.eq("id", userId));
			User user = (User) criteria.list().get(0);
			String email = user.getEmail();
			SimpleMailMessage mailMessage = new SimpleMailMessage();
			mailMessage.setFrom("admin@pcat.org");
			mailMessage.setTo(email);
			mailMessage.setSubject(
					"User + " + user.getFirstname() + " " + user.getLastname() + " ,your inventory of id : "+familyInventory.getInventory().getId() +" has been approved to family : "+familyInventory.getFamilyId() +"!");
			mailSender.send(mailMessage);
			completedApproval = true;
			tx.commit();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return completedApproval;
	}

	/**
	 * This method updates FamilyInventory with the "approved" status.
	 * @param familyInventory
	 * @return
	 */
	private boolean updateFamilyInventory(FamilyInventory familyInventory) 
	{
		boolean isUpdated = false;
		Transaction tx = null;
		try {
			Session session = sessionFactory.openSession();
			tx = session.beginTransaction();
			Criteria criteria = session.createCriteria(FamilyInventory.class);
			criteria.add(Restrictions.eq("id", familyInventory.getId()));
			FamilyInventory updateFamilyInventory = (FamilyInventory) criteria.list().get(0);
			updateFamilyInventory.setStatus(familyInventory.getStatus());
			session.update(updateFamilyInventory);
			isUpdated = true;
			tx.commit();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return isUpdated;
	}
}
